//LET VARIABLE=BLOCK-LEVEL OR GLOBAL LEVEL SCOPE//

let maggie="mag";
maggie="oo";
maggie=99;
console.log(maggie)

//----------------------------------------//
let person="sunny";person="supreeth";
console.log(person)
//------------------------------------------//


let  color="red";{

 let color="black";

}{
    colors="green";
    colors="light green"
    console.log(color,colors)
}
let y=9;
y="john"
console.log(y)
let u=28;
let ul=74;
console.log(u,ul)

//-------------------------------------------//
let k,l,p;
k=2+2;
l=3+3;
p=9+9;
console.log(k,l,p)