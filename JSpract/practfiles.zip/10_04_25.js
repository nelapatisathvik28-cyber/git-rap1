let carname="volvo"
console.log(carname)


var person="sunny"
console.log(person)


const boom=9999

console.log(boom)

let name="sathvik"
name="sunny"
console.log(name)

let any="car"
any=2874
console.log(any)

var rose="red"
rose=99990
console.log(rose)


 const cat="fish"
 console.log(cat)