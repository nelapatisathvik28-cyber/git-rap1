function myFun() {
    let carbeam = "read";
    let text = "Inside: " + typeof carbeam + " " + text; 
   console.log(carbeam,text)
  }
  
  myFun();