//1) In Synatx declare the variables//

let x=5;
 y=10;
p=25;
const z=25;
let u=x+y+z+p;
console.log(u)
//--------------------------------------//
let k,b
k=10;
b=20 ;
n =k+b

console.log( n)
//----------------------------------------//
// 2) statements//
var tvname="samsung";    //1st statement//
var tvName="sony";       //2md statement//
var  number=88;          //every excutable semicolon we called the  statement//

//---------------------------------------//

// 3)functions and calling functions//
function username(){
    let name="sunny"
     name = "booms";
    var names="boom";
    const namee= "kishor";
    var beam="rrr"
    var names='hit'
    console.log(name,namee,names,)

}
username()

//----------------------------------//
//Conditionals statements//
//comments//
//object types and arry//

