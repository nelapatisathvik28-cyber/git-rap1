//strings//
let a="sunny"
console.log(a)

let b="wsghydgcfweyfhwseid";
console.log(b)

//------------------------//
const x="it is kishor"
const y='it is pavan'
console.log(x + "<br> " +y)
//--------------------------//

let answer="it is 'question,"
let answers='it is !"answer"!,'
const answerss="what is your name'?',"
let total=answer+" "+answers+" "+answerss
console.log(total)

//-----------------------------------//

let ink=`it is "a"ink`
const inkk =`icfdweqapiofdjkweqp`
console.log(ink+ " is "+inkk)


//---------------------//
let ball=123445
ball=1010
const balls="aaAabbAA"
let namee="water"
console.log(ball+""+ball+""+balls)

//-----------------------------------//

const user="foxddddddddxc"
let user1="monkey"
let user3= 5 +""+"dog"
console.log(user.length)
//-------------------------------------//


let k="friend"
let k1="group"

console.log(k.charAt(0))

const opps="g7ahy"
const oppps="wedd"
var pppo="scdes"
console.log(opps.charCodeAt())

//------------------------------------------//

const name1="horse"
const name2='elephant'
const name3="crockodile"
console.log(name1.at(2))

//----------------------------------//

const nam="horse"
const namm='elephant'
const nammm="crockodile"
console.log(nammm.slice(3))

const rain1="fish"
const rain2='ant'
const rain3="eagle"
console.log(rain3.substring(1))

//-----------------------------------------//

let umberilla="eyewasd"
let umber='water'
let mmmm="tv"
console.log(umberilla.toUpperCase())
console.log(umber.toLocaleLowerCase())
//-------------------------------------------//



const username="sunny"
const username1='adhi'
const username2="ramu"
const username3=username1.concat("","",username2)
console.log(username3)

//--------------------------------------------//

let game="football"
let game1="kabbadi"
let game2='jp'
console.log()
//---------------------------//
const rain11="fish"
const rain21='ant'
const rain31="eagle"
console.log(rain31.substring(1))
//----------------------------//

const sub="jp"
const sub1="www.w3schools"
const sub3='hdasghbhcbhe'
const sub4=sub1+""+sub3+""+sub
console.log(sub3,sub1.substr(2))


const test="aaaaa"
const test1="bbbbb"
const test3="ddddd"
const test2=test3.trim()

const test4="eeeee"
const test11=test1.trim();
console.log(test1.length+" "+test3.length)

//--------------------------------------//
let machine="e`le`ctric"
let machine1=`hi i'am using 'your' "watch"`
console.log(machine ,machine1)

//-----------------------------------------//


let animal="tiger"
let animal2="lion"
let animal3="zebra"
let animals=`hii ${animal2} ${animal3}gbertfdvt`
console.log(animals)
//--------------------------------------//

let cost =10
let price =20
let costt =50
let pricee =50
let texxt=`hdccjdlo ${(cost*(price))} ${(costt +(pricee))}`
console.log(texxt)
//--------------------------------------//

let x1=40;
x1=50.9;
let x2=40;
console.log(x1+""+ x2)
//-----------------------------------//

const a1=12300e9
const a2=65100e-6
console.log(a2)
//--------------------------//

let i1=9999999999999999;
let i2=9999999999999999;
console.log(i1,i2)

let X=(0.2+6.6);
Y=9.5 +100;
console.log(X+""+Y)

//--------------------------//

let add= 10;
let add1= '20';
let add2= "sunny";
let add3="5ysunny";
console.log(add1+""+add3)

//------------------------------------//

let f="10"
let g="20"
let z= f-g
console.log(z)
//------------------------------------//
let c1=100/ "apple"
let c2=50/ "fruit"
console.log(c1,c2)
//-------------------------------------//
let cm=20/ "9"
console.log(isNaN(cm))
//-----------------------//
let cv="67"
console.log(typeof cv)
//---------------------//
let bv=0xFF;
console.log(bv)

const router=BigInt(12345678901234567890)
console.log(router)

let route=96669003239666900323n;
let route1=84640640738464064073n;
let totall=route*route1
console.log(typeof totall)
//------------------------------//
