//Numbers//

let color="red"
let color2="hello"
let range="syntax.js"
console.log(color,color2,range)
//----------------------------------//

const jan=10_1_25;
const jana=30_1_25;

const january=10.200
console.log(jan+"\n"+january)
//--------------------------------//


let feb=1020.01
let feb1=2025.2035000000000000000000000000
console.log(feb +"\n"+feb1)



let count="zebra"
let count2="hifi"
let chapter="tvm"
let hifi="news"
console.log(color2.codePointAt())


const cars = ["Saab", "Volvo", "BMW"];
cars.india="boom"
console.log(cars)

const vechicle=["bbbbbb"]
cars.jam=["hiffii"]
console.log(vechicle)

let wifi="opps"
wifi.ppppp="ssss"
console.log(wifi)


const fruits="fruit" 
console.log(fruits)


let hello="hii"
let hello1="booom"
console.log(hello,hello1)


let  consit=["boom","hello","yummy","sunny"]
consit[2]=11
consit.pipe="water"
console.log(consit)








