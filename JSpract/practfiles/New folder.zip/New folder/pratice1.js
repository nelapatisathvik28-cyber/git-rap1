//------------------------------//
//js change the html page//
x="sunny"
y="bunny"
console.log(x,y)


let y1=10
let z1=20
console.log(y1+z1)

let x1,x3,x4
x1=56
x2=76
x3=50
x4=x1-x2
console.log(x4)


//Variables//

var y5="56"
var y2="56"
var y5="76"
console.log(y5*y2)



const price1=25
const price2=35
const total=price1+price2
console.log(total)


let name="sunnny"
let name1="kishor"
console.log(name+"\n"
    +name1)


    var animale,animal2
    var animale="sunny"
    var animal1="adhi"
    var tottal1=animale+" "+animal1
    console.log(tottal1)



    carname="volvo"
    console.log(carname)
    var carname;





    var x=2
    {
        x=10
        x=25
    }{
        x=20
    }
var x=233
console.log(x)





const username=["sunny","ashok","adhi","tharun"]
username.push("uday")
username[0]='pavan'
username.slice(2,2)
console.log(username)



//arthametic operaters//
//string arthametic//
let color="red"
let color1="pink"
let color2="black"
console.log(color+color2)

let number=25
let number1=25
let totall=number+number1
console.log(totall)


let a=10
let cv=(10+20)*a
console.log(cv)

//assignment operator//
let n=20

n1=25
n2=44
n4=23
n5=n1+n2+n4
console.log(n5)


let n6=20

n6+=40
console.log(n6)

let text1="niceday"
 text1+="wdeqdd"
 console.log(text1)



