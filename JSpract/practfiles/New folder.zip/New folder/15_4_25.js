//1) In Synatx declare the variables//

let x5=5;
 y2=10;
p=25;
const z1=25;
let u=y2+p;
console.log(u)
//--------------------------------------//
let k1,b
k4=10;
b=20 ;
n =k4+b

console.log( n)
//----------------------------------------//
// 2) statements//
var tvname="samsung";    //1st statement//
var tvName="sony";       //2md statement//
var  number=88;          //every excutable semicolon we called the  statement//

//---------------------------------------//

// 3)functions and calling functions//
function username(){
    let name="sunny"
     name = "booms";
    var names="boom";
    const namee= "kishor";
    var beam="rrr"
    var names='hit'
    console.log(name,namee,names,)

}
username()

//----------------------------------//
//Conditionals statements//
//comments//
//object types and arry//


//variables//
let m=88
mm=99;
console.log(mm)


let carname1="bmw"; jar="tesla"
console.log(carname1,jar)


//-----------------function calling---------------//
function myfunction(){
    var name="sunny"
    var name="sunnys"
    const jigg="gunny"
    console.log(jigg,name)
}
myfunction()


//-------------------variables---------------------//
let y,g
y=10;
g=50;
let z=y+g
console.log(z)
//------------------------------------------//

const color2="red";
const color1="blue";
const total=color1+color2
console.log(total)



//---------------------------------------//
//var and let and const//

function userName(){
    var n="uuuu"
    var n="oooo"
}
{
    var n="pppp"
}
{
    var n="games"


console.log(n)
}
userName()


//------------------let block-level-scope-------------------------//
 function siva(){
    name="suraj";
      name="rohit";
     
      name="fjcfjed"
      name="hdfjdv"
      let namee="boom"
    console.log(name)

  } {
   let namee="yyyyy"
 name="whfhfw"
   console.log(name)
    }
 
 siva()
//----------------const block-level-scope---------------//
function router(){
    const movie="rrr"
    const movies="vicky"}
    {
const movies="war"
    }

    {
        const pop="gamboy"
        let popp="abhi"
        console.log(pop)
    }

    router()

    //-----------------------------------//
   

    //--------------var function-level-scope----------------------//
    var h=1+2+3+10;
    var h=99+100;

    var tname="john" +""+ "doe";
console.log(tname,h)


    //----------------------//

    let xii=1;

    {
        
     let  xii=4;
    }
    {
       const xii=3;

    }




    //CREAT OBJECT//

//-------------------------------------//

const person=[type="red",color="white",arry="car"];
person.color="pink";
console.log(person)


//---------------------------------//
const carname2={
    car:"bmw",car1
    :"volvo",car:"tvs",car3:"tesla"
};
carname2.car1="redddd";
console.log(carname2)


//-------------------------//
//constant object and array//
var username={
    user1:"sunny",user2:"siva",user3:"reddy"
};
username.drag="hello";
username.user1="bunny"
console.log(username)

//--------------ARRAY---------------------------//
 
let fruits=[apple="'3'",mango="5",papaya="10",greenapple="30"]
fruits.guava="10";
console.log(fruits)



carNamee="zebraaa";
console.log(carNamee)


//JS OPERATORS//
//arithmetic opretor//

let a5=10;
 b=20;
console.log(a5+b);
console.log(a5-b);
console.log(a5/b)
console.log(a5**b)
console.log(a5++)
//------------------//
//assignment//
let c=30;
d=25;
console.log(c===d)
console.log(c**=d)

//------------comparision operator-------------//

let j=100;
let k=100;
console.log(j+=k)

let s=25;
g=30;
console.log(s+=g)

//strings operaters//
let a1="ram";
a1 +="charan";
console.log(a1)

let a2="16"+"rain"
console.log(a2)

//--------------------------------//
//variables//
//function level scope//

var x7=10;
var pp="sunny";
console.log(pp)
//-------------------------------------------------------------------//

var user="syed";
{
    var user="kishor";

}
{
    var user="sai";
}
{
    var user ="yeswanth";
}

console.log(user)
//---------------------------------------------------------------------//

function boom(){
        var person22="dear";

    }
    {
        var person22=8;
    }
    {
        var person22=9;
        console.log(person22);
    }


    boom()

    //---------------------------------------//
    function beam(){
        var username="sathvik";
        
    }
    {
        username="zebra";
    }
    usernamee="kalyan";
console.log(username)
beam()
//--------------------------------------------------//

//logicaloperators//

let yy=10;
ii=20;
console.log("hi"+yy+ii)
//--------------------------//

//numbers//
let length = 16;
let weight = 7.5;
console.log(length,weight)
// Strings//
let colorr = "Yellow";
let lastName = "Johnson";
console.log(colorr+""+lastName)

// Booleans//
let xu = 5;
let yu = 6;
console.log(xu==yu)

//--------------------------------------------//

let wer="ii";
// functions//
let x3= UserName(4,3);
function UserName(a3,b3){
    return a3*b3;
}

function myanimal() {
    let texter = "";
    let texter1 = "Inside: " + typeof texter+ " " + texter1; 
   console.log(texter)
  }
//---------------------------------//
function poem(p1,p2){
    return p1 * p2;
  }
    
  
  let result = poem(21, 13);
  console.log(result)



  function myFun() {
    let carbeam = "read";
    let texta="boom" 
   console.log(carbeam+""+texta)
  }
  
  myFun();
  

  //object






