//strings//
let xv="beam"
xv="efwf"
console.log(xv.length,xv)

let car1="bmw";
car2="vo'l'vo";
console.log(car1+" "+car2)


//template string//

let x="hen"
let y=`fish  "ni'ce" 'to' see`
console.log(y)



let b="aaaaaaaaaaaaaaaaaaaaaaa"
v="fweolcfcfcfcfcfcfcfcfcf"
 w="djujujujujuju\"juju\"jujuju'\jujujujuju"
console.log(b.length,v["length"],w)
let car={}


//----------------------strings------------------------//
let text="john"
let texta="doe"
console.log(text+" "+texta)


let gear="bmw ' audi";
gear2="hifi 'wifi'"
console.log(gear , gear2)


let breakk= "kalyan ' ram";
break1 = "ntr"
console.log(`${breakk}+"/n"+{break1}`)

let a1=11
let a2="sunny"
console.log(a1+"\n"+a2)


//----------------------------//
let animal="ca't"
let animal2="fi`ddd'sh"
console.log(animal,animal2)

let anima="snak77";
let animall="dddd"
console.log(`${animall}${anima}`)

let fish="animal"
let good=`${"jjjjjj"}`
console.log(good)


//-----------------------------------//
const names="throlik"
namess=`${"names"} ${6666}`
console.log(namess,names)
console.log(`${namess}`)
console.log(`${namess}`)
console.log(`${namess}`)
console.log(`${namess}`)
console.log(`${namess}`)
console.log(`${namess}`)
console.log(`${namess}`)
console.log(`${namess.length}`)

//---------------------------------//
//templates are not supported in internet explorer//
//---------stringlength//
let hifi="it is good palace"
console.log(hifi.length)

let jk="th\\i\s is \"sun\vny to\"  go mo\'v\'ie";

const keep="ehrdb\twf\ffc\vhbnhvcf\bkievcf/bh"

const jeep="sunnyis \rgood b"
console.log(jk +"\n"+ keep+"\n"+jeep)

let neww=`alloed yyi       it is taking "long line and it will \ntake the singlequpteam=nd double quote`

console.log(neww

)

let x1="john"
let x2 = new String("sunny")
console.log(x2)



let x11=new String("suresh")
let x22=new String("kishor")
console.log(x22,x11)


let fire=new Object("fireengine")
console.log(fire)

let xb="john"
xb="hifii"
console.log(xb)

let rc="ktm"
let xc=new Object("ktm")
console.log(xc+" \n"+rc)

let xf= new Object("sunny")//string//
let ok=new Object("sunny")//object//
console.log(xf,ok)


let xuv="alternating"
let xev="tharun"
console.log(xuv.length,xev.length)

//--------------------------------------//

//string methods//
let cv="11111111111111111111111111111efdfdfdfdfdfdfdfdfdfd11"
const bnm="dkkkkkkkkkkkkkkkkkkkkkggggggggggkkkkc"
console.log(cv.length,bnm["length"])




let rg="boom"
let vt="siva"
const hh="prasad"
console.log(rg.charAt(0))


let uber= "hhhuh"
let hiwiii="bbbbbb"
console.log(uber.charAt(3))



let auto="kalyan"
const bus="driver"
console.log(auto+""+bus.charAt(0))


let students="teacher"
let student="5 peoples"
console.log(students.charAt(5))
console.log(student.charAt(2))


let user="names"
let user1="adress"
console.log(user.charCodeAt(0),user1.charCodeAt(1))//UTF-16//
//------------------------------//

let resultt="student"

let userr=resultt[2]
console.log(userr)



let gumm="sunny"
let res=gumm[2]
console.log(res)

let yu="kishordxhhh,dledloe";
let yy=yu.slice(2,7);
console.log(yy)



let moon="arunvamsi"
let boomm=moon.slice(6,9)
console.log(boomm)




let water="raghuvaran"
console.log(water.substring(2,12))



let warm="abcdefghijklmnop"
let part=warm.substr(2,5)
console.log(part)



//---------------------//


let work="office"
let table="tv"
let tab=work.toUpperCase(2)
console.log(tab)


let booms="uuuu"
let i="gdyyg"
let remo=booms.toUpperCase()
console.log(remo,i.toUpperCase())


//----------concat-------------//
let x23="hello"
let x33="my world"
let x44=x23.concat("",x33)
console.log(x44)


//----------------------------//

let s1="beam"
let ssrt="air"
let s4=ssrt.concat(" " , s1)
console.log(s4)
//=---------------------------=//


let time=                                          "                        sometime"
let date="somedate"
let fate=time.trimStart()
console.log(time.length)


let eyes="              redcolor           "
let eye=eyes.trim()
console.log(eye)



let ratio="     radio"
let op=ratio.trimEnd()
console.log(op)

let rainn="5"
let ram=rainn.padStart(4,9)
console.log(ram)

let swims="10"
let swim=swims.padStart(5,0)
console.log(swim)



let varm=6
let zam=varm.toString()

console.log(zam.padStart(4,3))  


let waterr="sea"
let zoom=waterr.repeat(3)
console.log(zoom)

let namee="pavan"
let namee1="sasi"
console.log(namee.repeat(5)+"\n"+namee1.repeat(5))




//----------------------//

let tex="i love cats in india.it is high mountain Cats"
tex=tex.replaceAll("cats","dogs") ;
tex=tex.replaceAll("Cats","fish")


console.log(tex)


let animalss="5"
let ani=animalss.padStart(4,0)
console.log(ani)


let odd="text"
let odds=odd.substr(2,4)
console.log(odds)


let jp="template"
let fruit=jp.replace("template","sun")
console.log(fruit)
