//-------------------------STRINGS----------------------------//
let x="sunny"
y="kishor"
console.log(x,y,)
z="adhi"
console.log(z)


const  tt="hifi"
let yy=2874
console.log(tt+"\n"+yy)


let van="bus"
const van1="volvol"
let van2= new String(van1)
console.log(van2)




//---------------------------------------------//



let animal="fish 99999999999999"
let animal1="goat"
let animal2=animal.length
console.log(animal2)
//----------------------------------//

let namee="pavan"
let namee1="ashok"
console.log(namee1["length"])
//-----------------------------------//

let personn={first:"name",
second:"secondne",
third:"thirdname",
fourth:"property_name"
};
let xv=personn.first["length"]
let xn=personn.second.charCodeAt()
console.log(personn.first.length)


//--------------------------------------//



let cv="999999999999aaaaaaaaaaaaaaaaaaaa"
let om="qqqqqqqqqqqqqqqqqqqjnq"
let cp="ppppppppppp"
let cx= `${om.length} ${cv.length} ${cp.charAt(5)}`
console.log(cv.length,om.length,cx.length)


let bn="dear"
let bt="home"
const kim=bn.at(1)
console.log(kim)

let ussr="boom"
usern="work"
usernn=usern.charCodeAt(3)
console.log(usernn)



let x2=" "
let x3="suny"
console.log(x2,x3)



let username="hhh4"
let jk=username.at(3)

console.log(jk)
let k3="jjjj"
console.log(k3)
let use="1234"
console.log(x3)


let text="sunny"
let text1="55"
 text2=text1.concat("","text")






 let ltext="hifi"
 let itext="      wifi      "
 let ktext=itext.trimEnd()
 console.log(ktext)


 let textt1 = "     Hello   World     !     ";
let textt2 = textt1.trim().replace(/\s+/g,"");

console.log(textt2); 

let texttt1= "hello world                77"
let sun=texttt1.trim().replace(/\s+/g," ");
console.log(sun)

//-----------------------------------------//

 let tetx = "I like JavaScript.  JavaScript is fun.";
console.log(tetx.lastIndexOf("JavaScript")); 


let taste="food is 'food' taste"
let taste1=taste.lastIndexOf("food")
console.log(taste1)


let tank="kfc"
let tank1="pizzaa is the so taste"
let tank2=tank1.indexOf("is")
console.log(tank2)



let tub="meals"
let tub1="eggs ffff ff it is new name  of the name water"
let tub2=tub1.lastIndexOf("name")
console.log(tub2)

let cube="3spides"
let cube1=cube.search("s")
console.log(cube1)


let tree="leafes"
let tree1=tree.match("af")
console.log(tree1)

let index="rain is falling in the sky"
 let index1=index.match();
 console.log(index1)


 let inde="We are palying in the groud"

 let indee=inde.startsWith("We")
 console.log(indee)


 let home="this place is good"
 let home1=home.endsWith("good")
 console.log(home1)

let homee="it is good 7"
let homer= homee.includes("it")
console.log("homer")



let hom="gwehydkisg"
 let hh="egdfvykiuhzvs"
 console.log(hom +"\n"+ hh)

 let color="color"
 let gear="fiiiill"

console.log(color,gear)





            